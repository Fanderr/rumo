package com.example.rumo0716_bna.ui.search;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.rumo0716_bna.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class SearchResultFragment extends Fragment {

    TextView editSearch_02;
    String str[];//GetFake
    String str1[];//GetCorrect
    String[] sw;//儲存使用者輸入的關鍵字
    int usinput=-1;//使用者輸入是假的是0，是真的是1
    private ListView listView;
    private ImageView imageView14;
    private ImageView imageView6;
    private ListAdapter listAdapter;
    //listAdapter = new ArrayAdapter<String>

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_search_result, container, false);
        editSearch_02 = root.findViewById(R.id.textView4);
        editSearch_02.setText(SearchFragment.tex);
        listView=root.findViewById(R.id.listView);
        imageView14=root.findViewById(R.id.imageView14);
        imageView6=root.findViewById(R.id.imageView6);
        sw=new String[]{"美国", "大兵", "蝙蝠"};
        listAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, sw);
        listView.setAdapter(listAdapter);
        // imageView14.setImageResource(R.drawable.battery_1);
        // imageView14.setBackgroundResource(R.drawable.battery_2);

        //充電圖示-有多假
        int a=49;int b=0;
        if(a>75){b=0;}
        if(a>50||a<=75){b=1;}
        if(a>25||a<=50){b=2;}
        if(a<=25){b=3;}
        switch (b) {
            case 0:
                imageView14.setImageResource(R.drawable.battery_4);
                break;
            case 1:
                imageView14.setImageResource(R.drawable.battery_3);
                break;
            case 2:
                imageView14.setImageResource(R.drawable.battery_2);
                break;
            case 3:
                imageView14.setImageResource(R.drawable.battery_1);
                break;
        }



        Thread thread = new Thread(mthread);
        thread.start();
        try{
            thread.join();}
        catch (Exception e){

        }


        return root;
    }
    private Runnable mthread = new Runnable() {
        @Override

        public void run() {
            try {
                URL url = new URL("http://192.168.43.17/GetFake.php");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                // 建立 Google 比較挺的 HttpURLConnection 物件
                connection.setRequestMethod("POST");
                // 設定連線方式為 POST
                connection.setDoOutput(false); // 允許輸出
                connection.setDoInput(true); // 允許讀入
                connection.setUseCaches(false); // 不使用快取
                connection.connect(); // 開始連線
                int responseCode =
                        connection.getResponseCode();
                // 建立取得回應的物件
                if (responseCode ==
                        HttpURLConnection.HTTP_OK) {
                    // 如果 HTTP 回傳狀態是 OK ，而不是 Error
                    InputStream inputStream =
                            connection.getInputStream();
                    // 取得輸入串流
                    BufferedReader bufReader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
                    // 讀取輸入串流的資料
                    String box = ""; // 宣告存放用字串
                    String line = null; // 宣告讀取用的字串
                    while ((line = bufReader.readLine()) != null) {
                        box = box + line;
                    }
                    box=box.replace("[{", "");
                    box=box.replace("}]", "");

                    String s = "\\}\\,\\{";
                    str = box.split(s);
                    inputStream.close(); // 關閉輸入串流

                    //抓取正確資訊
                    URL url1 = new URL("http://192.168.43.17/GetCorrect.php");
                    HttpURLConnection connection1 = (HttpURLConnection) url1.openConnection();
                    // 建立 Google 比較挺的 HttpURLConnection 物件
                    connection1.setRequestMethod("POST");
                    // 設定連線方式為 POST
                    connection1.setDoOutput(false); // 允許輸出
                    connection1.setDoInput(true); // 允許讀入
                    connection1.setUseCaches(false); // 不使用快取
                    connection1.connect(); // 開始連線
                    int responseCode1 =
                            connection1.getResponseCode();
                    // 建立取得回應的物件
                    if (responseCode1 ==
                            HttpURLConnection.HTTP_OK) {
                        // 如果 HTTP 回傳狀態是 OK ，而不是 Error
                        InputStream inputStream1 =
                                connection1.getInputStream();
                        // 取得輸入串流
                        BufferedReader bufReader1 = new BufferedReader(new InputStreamReader(inputStream1, "utf-8"));
                        // 讀取輸入串流的資料
                        String box1 = ""; // 宣告存放用字串
                        String line1 = null; // 宣告讀取用的字串
                        while ((line1 = bufReader1.readLine()) != null) {
                            box1 = box1 + line1;
                        }

                        box1=box1.replace("["+"{", "");
                        box1=box1.replace("}"+"]", "");
                        String s1 = "\\}\\,\\{";
                        str1 = box1.split(s1);
                        inputStream1.close(); // 關閉輸入串流
                    }
                }
                for(int i=0;i<str1.length;i++){//GetCorrect-0
                    String s1 = str1[i];
                    s1.replace("[","").replace("{","").replace("ID","").replace(":","").replace("SOURCE","");
                    s1.replace("CONTENT","").replace("KEY1","").replace("KEY2","").replace("KEY3","").replace("COLLECT","").replace("WATCH","");
                    s1.replace("}","").replace("]","").replace("\"","");
                    String ss1[]=s1.split(",");
                    for(int j=0;j<ss1.length;j++) {
                        if (ss1[j].equals(sw[0])) {
                            usinput = 0;
                        }
                    }
                    //1,cofact,立刻停用檢修12品牌54款除濕機召回LINETODAY,品牌,檢修,濕機,0,0,

                }
                for(int i=0;i<str.length;i++){//GetFake-1
                    String s1 = str[i];
                    s1.replace("[","").replace("{","").replace("ID","").replace(":","").replace("SOURCE","");
                    s1.replace("CONTENT","").replace("KEY1","").replace("KEY2","").replace("KEY3","").replace("COLLECT","").replace("WATCH","");
                    s1.replace("}","").replace("]","").replace("\"","");
                    String ss1[]=s1.split(",");
                    for(int j=0;j<ss1.length;j++){
                        if(ss1[j].equals(sw[0])){usinput=1;}
                    }
                    //1,cofact,立刻停用檢修12品牌54款除濕機召回LINETODAY,品牌,檢修,濕機,0,0,

                }

                /*for(int i=0;i<str1.length;i++){
                    str1[i]=str1[i].replace(":",",");
                    //str1[i]=str1[i].replace(",",",");
                    str1[i]=str1[i].replace("\"","");
                    String[]fakesp=str1[i].split(",");//7,9,11
                    String[]keys={fakesp[7],fakesp[9],fakesp[11]};
                    for(int j=0;j<fakesp.length;j++){if(sw[0].equals(fakesp[j])){ usinput=0;}}
                    if(sw[0].equals(keys[0])||sw[0].equals(keys[1])||sw[0].equals(keys[2])){
                        if(sw[1].equals(keys[0])||sw[1].equals(keys[1])||sw[1].equals(keys[2])){
                            if(sw[2].equals(keys[0])||sw[2].equals(keys[1])||sw[2].equals(keys[2])){
                               // imageView6.setImageResource(R.drawable.alert);
                                //usinput=0;
                                //imageView6.setImageResource(R.drawable.wrong);
                            }
                        }//imageView6.setImageResource(R.drawable.wrong);
                    }
                }*/
                /*for(int i=0;i<str.length;i++){
                    str[i]=str[i].replace(":",",");
                    str1[i]=str1[i].replace("\"","");
                    String[]corsp=str[i].split(",");//7,9,11
                    String[]keys={corsp[7],corsp[9],corsp[11]};
                    for(int j=0;j<corsp.length;j++){if(sw[0].equals(corsp[j])){ usinput=1;}}
                    if(sw[0].equals(keys[0])||sw[0].equals(keys[1])||sw[0].equals(keys[2])){
                        if(sw[1].equals(keys[0])||sw[1].equals(keys[1])||sw[1].equals(keys[2])){
                            if(sw[2].equals(keys[0])||sw[2].equals(keys[1])||sw[2].equals(keys[2])){
                                //imageView6.setImageResource(R.drawable.wrong);

                            }
                        }
                    }
                }*/
                if(usinput==1){imageView6.setImageResource(R.drawable.wrong);}
                else if(usinput==0){imageView6.setImageResource(R.drawable.alert);}
                else{imageView6.setImageResource(R.drawable.allow);}



            }
            catch(Exception e){
                System.out.println(e);
            }
        }

    };

   /* public interface OnButtonClick{
        public void onClick(View view);
    }*/



}
