package com.example.rumo0716_bna.ui.collect;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.rumo0716_bna.R;
import com.example.rumo0716_bna.ui.adapter.CollectRecycleAdapter;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


public class CollectFragment extends Fragment {
    private View view;//定義view用來設定fragment的layout
    public RecyclerView mCollectRecyclerView;//定義RecyclerView
    //定義以collectArticles實體類為物件的資料集合
    private ArrayList<CollectArticles> collectArticlesList = new ArrayList<CollectArticles>();
    private ArrayList<CollectArticles> recommendArticlesList = new ArrayList<CollectArticles>();
    //自定義recyclerveiw的介面卡
    private CollectRecycleAdapter mCollectRecyclerAdapter;

    String username="yen";//使用者帳號
    String result1, result2;//儲存資料用的字串
    private int id;//儲存文章id

    int alert_num=0;//正確數量
    int wrong_num=0;//錯誤數量

    TextView alertnum, wrongnum;

    private CollectViewModel collectViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //獲取fragment的layout
        view = inflater.inflate(R.layout.fragment_collect, container, false);
        alertnum=(TextView) view.findViewById(R.id.alertnum);
        wrongnum=(TextView) view.findViewById(R.id.wrongnum);
        //對recycleview進行配置
        initRecyclerView_collect();
        //模擬資料
        initData_collect();

        alertnum.setText(alert_num+"");
        wrongnum.setText(wrong_num+"");
        //對recycleview進行配置
        initRecyclerView_recommend();
        //模擬資料
        initData_recommend();

        return view;
    }
    /**
     *  模擬資料
     */

    private void initData_collect() { //去資料庫撈
        Thread thread = new Thread(mutiThread);
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String alert_id=result1.split(",")[3].split(":")[1];
        alert_id=alert_id.substring(1,alert_id.lastIndexOf("\""));
        String wrong_id=result1.split(",")[2].split(":")[1];
        wrong_id=wrong_id.substring(1,wrong_id.lastIndexOf("\""));
        alert_num=alert_id.split("\\.").length;
        wrong_num=wrong_id.split("\\.").length;
        int type=0;
        String imgPath="";
        for (int i=0;i<alert_num+wrong_num;i++){
            if(i<alert_num){
                id=Integer.parseInt(alert_id.split("\\.")[i]);
                type=0;
                imgPath="alert";
            }else{
                id=Integer.parseInt(wrong_id.split("\\.")[i-alert_num]);
                type=1;
                imgPath="wromg";
            }
            articleThread articleThread = new articleThread(id,type);
            Thread t = new Thread(articleThread);
            t.start();
            try {
                t.join();
            }catch (InterruptedException e) {
                e.printStackTrace();
            }
            CollectArticles collectArticles=new CollectArticles();
            String source=result2.split(",")[1].split(":")[1].split("\"")[1];
            collectArticles.setImgPath(imgPath);
            collectArticles.setSource(source);
            collectArticles.setContent(result2.split(",")[2].split(":")[1].substring(1,11)+"...");
            collectArticlesList.add(collectArticles);
        }

    }
    private Runnable mutiThread = new Runnable(){
        public void run()
        {
            try {
                URL url = new URL("http://192.168.43.17/GetUser.php");
                // 開始宣告 HTTP 連線需要的物件，這邊通常都是一綑的
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                // 建立 Google 比較挺的 HttpURLConnection 物件
                connection.setRequestMethod("POST");
                // 設定連線方式為 POST
                connection.setDoOutput(false); // 允許輸出
                connection.setDoInput(true); // 允許讀入
                connection.setUseCaches(false); // 不使用快取
                connection.connect(); // 開始連線

                int responseCode =
                        connection.getResponseCode();
                // 建立取得回應的物件
                if(responseCode ==
                        HttpURLConnection.HTTP_OK){
                    // 如果 HTTP 回傳狀態是 OK ，而不是 Error
                    InputStream inputStream =
                            connection.getInputStream();
                    // 取得輸入串流
                    BufferedReader bufReader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
                    // 讀取輸入串流的資料
                    String box = ""; // 宣告存放用字串
                    String line = null; // 宣告讀取用的字串
                    while((line = bufReader.readLine()) != null) {
                        //System.out.println(line);
                        String[] ss=line.split("\\}\\,\\{");
                        for(int i=0;i<ss.length;i++){
                            if(ss[i].split(",")[0].split(":")[1].equals("\""+username+"\"")){
                                box=ss[i];
                                //System.out.println("box="+box);
                                break;
                            }
                        }
                    }
                    inputStream.close(); // 關閉輸入串流
                    result1 = box; // 把存放用字串放到全域變數
                    //System.out.println("result1="+result1);
                }
                // 讀取輸入串流並存到字串的部分
                // 取得資料後想用不同的格式
                // 例如 Json 等等，都是在這一段做處理

            } catch(Exception e) {
                result1 = e.toString(); // 如果出事，回傳錯誤訊息
            }

        }
    };
    private class articleThread implements Runnable{
        int id;
        int type;
        public articleThread(int id,int type) {
            this.id=id;
            this.type=type;
        }

        @Override
        public void run() {
            try {
                URL url;
                if(type==0){
                    url = new URL("http://192.168.43.17/GetCorrect.php");
                }else{
                    url = new URL("http://192.168.43.17/GetFake.php");
                }
                // 開始宣告 HTTP 連線需要的物件，這邊通常都是一綑的

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                // 建立 Google 比較挺的 HttpURLConnection 物件
                connection.setRequestMethod("POST");
                // 設定連線方式為 POST
                connection.setDoOutput(false); // 允許輸出
                connection.setDoInput(true); // 允許讀入
                connection.setUseCaches(false); // 不使用快取
                connection.connect(); // 開始連線

                int responseCode =
                        connection.getResponseCode();
                // 建立取得回應的物件
                if(responseCode ==
                        HttpURLConnection.HTTP_OK){
                    // 如果 HTTP 回傳狀態是 OK ，而不是 Error
                    InputStream inputStream =
                            connection.getInputStream();
                    // 取得輸入串流
                    BufferedReader bufReader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
                    // 讀取輸入串流的資料
                    String box = ""; // 宣告存放用字串
                    String line = null; // 宣告讀取用的字串
                    while((line = bufReader.readLine()) != null) {
                        //System.out.println("line="+line);
                        String[] ss=line.split("\\}\\,\\{");
                        for(int i=0;i<ss.length;i++){
                            if(Integer.parseInt(ss[i].split(",")[0].split(":")[1].split("\"")[1])==id){
                                if(i==0){
                                    box=ss[i].split("\\{")[1];
                                }else if(i==ss.length-1){
                                    box=ss[i].split("\\}")[0];
                                }else{
                                    box=ss[i];
                                }
                                //System.out.println("BOX="+box);
                                break;
                            }
                        }

                    }
                    inputStream.close(); // 關閉輸入串流
                    result2 = box; // 把存放用字串放到全域變數
                }
                // 讀取輸入串流並存到字串的部分
                // 取得資料後想用不同的格式
                // 例如 Json 等等，都是在這一段做處理

            } catch(Exception e) {
                result2 = e.toString(); // 如果出事，回傳錯誤訊息
            }
        }


    }

    /**
     *  對recycleview進行配置
     */

    private void initRecyclerView_collect() {
        //獲取RecyclerView
        mCollectRecyclerView=(RecyclerView)view.findViewById(R.id.collect_recyclerView);
        //設定layoutManager,可以設定顯示效果，是線性佈局、grid佈局，還是瀑布流佈局
        //引數是：上下文、列表方向（橫向還是縱向）、是否倒敘
        mCollectRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        //設定article的分割線
        mCollectRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(),DividerItemDecoration.VERTICAL));
        //建立adapter
        mCollectRecyclerAdapter = new CollectRecycleAdapter(getActivity(), collectArticlesList);
        //給RecyclerView設定adapter
        mCollectRecyclerView.setAdapter(mCollectRecyclerAdapter);
        //RecyclerView中沒有item的監聽事件，需要自己在介面卡中寫一個監聽事件的介面。引數根據自定義
        mCollectRecyclerAdapter.setOnItemClickListener(new CollectRecycleAdapter.OnItemClickListener() {
            @Override
            public void OnItemClick(View view, CollectArticles data) {
                //此處進行監聽事件的業務處理
                Toast.makeText(getActivity(),"我是item",Toast.LENGTH_SHORT).show(); //顯示氣泡訊息
            }
        });
    }

    private void initData_recommend() { //去資料庫撈
        for (int i=0;i<3;i++){
            CollectArticles recommendArticles=new CollectArticles();
            recommendArticles.setImgPath("alert");
            recommendArticles.setSource("模擬資料"+i);
            recommendArticles.setContent("100"+i);
            recommendArticlesList.add(recommendArticles);
        }
    }

    private void initRecyclerView_recommend() {
        //獲取RecyclerView
        mCollectRecyclerView=(RecyclerView)view.findViewById(R.id.recommend_recyclerview);
        //建立adapter
        mCollectRecyclerAdapter = new CollectRecycleAdapter(getActivity(), recommendArticlesList);
        //給RecyclerView設定adapter
        mCollectRecyclerView.setAdapter(mCollectRecyclerAdapter);
        //設定layoutManager,可以設定顯示效果，是線性佈局、grid佈局，還是瀑布流佈局
        //引數是：上下文、列表方向（橫向還是縱向）、是否倒敘
        mCollectRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        //設定article的分割線
        mCollectRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(),DividerItemDecoration.VERTICAL));
        //RecyclerView中沒有item的監聽事件，需要自己在介面卡中寫一個監聽事件的介面。引數根據自定義
        mCollectRecyclerAdapter.setOnItemClickListener(new CollectRecycleAdapter.OnItemClickListener() {
            @Override
            public void OnItemClick(View view, CollectArticles data) {
                //此處進行監聽事件的業務處理
                Toast.makeText(getActivity(),"我是item",Toast.LENGTH_SHORT).show(); //顯示氣泡訊息
            }
        });
    }


}


