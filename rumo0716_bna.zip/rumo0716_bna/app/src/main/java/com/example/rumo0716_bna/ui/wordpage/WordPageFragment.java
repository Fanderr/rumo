package com.example.rumo0716_bna.ui.wordpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.rumo0716_bna.R;
import com.example.rumo0716_bna.ui.home.HomeFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;


public class WordPageFragment  extends Fragment {
    private View view;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_wordpage, container, false);
        Thread thread = new Thread(mthread);//觀看數增加一
        thread.start();
        try{
            thread.join();}
        catch (Exception e){
        }
        if(HomeFragment.ju_source.equals("事實審查中心")){
            ImageView m=view.findViewById(R.id.block);
            m.setBackground(getResources().getDrawable(R.drawable.logo_2));
        }
        if(HomeFragment.ju_correct_or_fake){
            ImageView cross = view.findViewById(R.id.cross4);
            cross.setBackground(getResources().getDrawable(R.drawable.alert));
            TextView icon = view.findViewById(R.id.textView36);
            icon.setText("小心");
        }
        TextView text = view.findViewById(R.id.textView26);//文章內容
        text.setText(HomeFragment.ju_context);
        TextView title = view.findViewById(R.id.textView27);//標題
        title.setText(HomeFragment.ju_article);
        //關鍵字
        TextView keyword1 = view.findViewById(R.id.textView23);
        TextView keyword2 = view.findViewById(R.id.textView24);
        TextView keyword3 = view.findViewById(R.id.textView25);
        keyword1.setText(HomeFragment.ju_key1);
        keyword2.setText(HomeFragment.ju_key2);
        keyword3.setText(HomeFragment.ju_key3);
        //觀看數與收藏數
        TextView watch_count = view.findViewById(R.id.textView28);
        TextView collect_count = view.findViewById(R.id.textView31);
        watch_count.setText(HomeFragment.ju_search);
        collect_count.setText(HomeFragment.ju_love);
        //你可能感興趣的文章
        if(HomeFragment.ju_correct_or_fake){
            interesting(HomeFragment.str);
        }
        else{
            interesting(HomeFragment.str1);
        }
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //       .setAction("Action", null).show();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "我要分享這段文字");
                sendIntent.setType("text/plain");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
            }
        });

        return view;
    }
    private Runnable mthread=new Runnable(){
        public void run(){
        try{
            if(HomeFragment.ju_correct_or_fake) {
                URL url = new URL("http://192.168.43.17/WatchAddOneCo.php");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                // 建立 Google 比較挺的 HttpURLConnection 物件
                connection.setRequestMethod("POST");
                // 設定連線方式為 POST
                connection.setDoOutput(true); // 允許輸出
                connection.setDoInput(true); // 允許讀入
                connection.setUseCaches(false); // 不使用快取
                connection.connect(); // 開始連線
                OutputStream ot = connection.getOutputStream();
                OutputStreamWriter or = new OutputStreamWriter(ot, "UTF-8");
                or.write(String.valueOf(HomeFragment.ju_home_text_id));
                or.flush();
                or.close();
                ot.close();
                InputStream is = connection.getInputStream();
                InputStreamReader ir= new InputStreamReader(is);
                ir.close();
                is.close();
                connection.disconnect();


            }
            else {
                URL url = new URL("http://192.168.43.17/WatchAddOneFa.php");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                // 建立 Google 比較挺的 HttpURLConnection 物件
                connection.setRequestMethod("POST");
                // 設定連線方式為 POST
                connection.setDoOutput(true); // 允許輸出
                connection.setDoInput(true); // 允許讀入
                connection.setUseCaches(false); // 不使用快取
                connection.connect(); // 開始連線
                OutputStream ot = connection.getOutputStream();
                OutputStreamWriter or = new OutputStreamWriter(ot,"UTF-8");
                or.write(String.valueOf(HomeFragment.ju_home_text_id));
                or.flush();
                or.close();
                ot.close();
                InputStream is = connection.getInputStream();
                InputStreamReader ir= new InputStreamReader(is);
                ir.close();
                is.close();
                connection.disconnect();
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
    };
    public void interesting(String txt[]){
        int idlist[]=new int[3];
        int cnt=0;
        for(int i=0;i<txt.length;i++) {
            if (i == HomeFragment.ju_home_text_id - 1) i++;
            String each[] = txt[i].split(",");
            String k1 = each[3].replace("KEY1", "").replace("\"", "").replace(":", "");
            String k2 = each[4].replace("KEY2", "").replace("\"", "").replace(":", "");
            String k3 = each[5].replace("KEY3", "").replace("\"", "").replace(":", "");
            ArrayList a = new ArrayList();
            a.add(k1);
            a.add(k2);
            a.add(k3);
            if (a.contains(HomeFragment.ju_key1) || a.contains(HomeFragment.ju_key2) || a.contains(HomeFragment.ju_key3)) {
                idlist[cnt] = Integer.parseInt(each[0].replace("ID", "").replace("\"", "").replace(":", "").replace("[", "").replace("{", ""));
                cnt++;
            }
            if(cnt==3)break;
            if(i==txt.length-1){
                for(int j=cnt;j<3;j++){
                    idlist[j]= (int)(Math.random()*1000)+1;
                }
            }
        }
        String recommend[]=txt[idlist[0]+1].split(",");
        TextView s1 =view.findViewById(R.id.textView2);
        TextView t1 =view.findViewById(R.id.textView9);
        TextView w1 =view.findViewById(R.id.textView29);
        TextView l1 =view.findViewById(R.id.textView30);
        s1.setText(recommend[1].replace("SOURCE","").replace("\"","").replace(":",""));
        t1.setText(recommend[2].replace("CONTENT","").replace("\"","").replace(":",""));
        w1.setText(recommend[7].replace("WATCH","").replace("\"","").replace(":",""));
        l1.setText(recommend[6].replace("COLLECT","").replace("\"","").replace(":",""));

        String recommend1[]=txt[idlist[1]+1].split(",");
        TextView s2 =view.findViewById(R.id.textView13);
        TextView t2 =view.findViewById(R.id.textView18);
        TextView w2 =view.findViewById(R.id.textView32);
        TextView l2 =view.findViewById(R.id.textView33);
        s2.setText(recommend1[1].replace("SOURCE","").replace("\"","").replace(":",""));
        t2.setText(recommend1[2].replace("CONTENT","").replace("\"","").replace(":",""));
        w2.setText(recommend1[7].replace("WATCH","").replace("\"","").replace(":",""));
        l2.setText(recommend1[6].replace("COLLECT","").replace("\"","").replace(":",""));

        String recommend2[]=txt[idlist[2]+1].split(",");
        TextView s3 =view.findViewById(R.id.textView21);
        TextView t3 =view.findViewById(R.id.textView22);
        TextView w3 =view.findViewById(R.id.textView34);
        TextView l3 =view.findViewById(R.id.textView35);
        s3.setText(recommend2[1].replace("SOURCE","").replace("\"","").replace(":",""));
        t3.setText(recommend2[2].replace("CONTENT","").replace("\"","").replace(":",""));
        w3.setText(recommend2[7].replace("WATCH","").replace("\"","").replace(":",""));
        l3.setText(recommend2[6].replace("COLLECT","").replace("\"","").replace(":",""));

    }
}
