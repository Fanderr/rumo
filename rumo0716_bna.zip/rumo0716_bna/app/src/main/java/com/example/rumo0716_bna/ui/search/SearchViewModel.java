package com.example.rumo0716_bna.ui.search;

import android.content.Intent;
import android.widget.SearchView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.rumo0716_bna.MainActivity;

public class SearchViewModel extends ViewModel {
    public void search(ViewModel viewModel){

    }
}